# c1=complex(2,5)
# print(c1)
# c2=complex(7,8)
# print(c2)
# print(c1+c2).

class A:
    def __init__(Self):
        print("ConstructorA")
class B(A):    
    def __init__(Self):
        print("ConstructorB")

    b1= B()
    
print (b1) 






